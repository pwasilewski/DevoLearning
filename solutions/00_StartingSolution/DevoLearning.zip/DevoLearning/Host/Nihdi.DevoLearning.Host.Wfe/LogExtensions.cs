﻿// <copyright file="LogExtensions.cs" company="Riziv-Inami">
// Copyright (c) Riziv-Inami. All rights reserved.
// </copyright>

namespace Nihdi.DevoLearning.Host.Wfe
{
    public static partial class LogExtensions
    {
        [LoggerMessage(EventId = 0, Message = "Starting application {workloadName}, environment is {environment}.", Level = LogLevel.Information)]
        public static partial void LogStartApplication(
            this ILogger logger,
            string workloadName,
            string environment);

        [LoggerMessage(EventId = 1, Message = "Host terminated unexpectedly.", Level = LogLevel.Critical)]
        public static partial void LogHostTerminated(
            this ILogger logger,
            Exception ex);
    }
}
