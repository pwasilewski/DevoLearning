﻿namespace Nihdi.DevoLearning.Host.Wfe
{
    using System.Text.Json;
    using Microsoft.Extensions.Logging;
    using MudBlazor.Services;
    using Nihdi.Core.Configuration;
    using Nihdi.Core.Configuration.BlazorServer.Extensions;
    using Nihdi.Core.Configuration.Common.Extensions;
    using Nihdi.Core.Configuration.Common.Logging;
    using Nihdi.Core.Configuration.OpenIdConnect.Extensions;
    using Nihdi.Core.Configuration.Settings;
    using Nihdi.DevoLearning.Presentation;

    /// <summary>
    /// The program.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Program"/> class.
        /// </summary>
        protected Program()
        {
        }

        /// <summary>
        /// Gets or sets the nihdi configuration.
        /// </summary>
        /// <value>
        /// The nihdi configuration.
        /// </value>
        public static NihdiConfiguration NihdiConfiguration { get; set; } = new NihdiConfiguration();

        /// <summary>
        /// Entrypoint of Program.
        /// </summary>
        /// <param name="args">The args.</param>
        /// <returns>An int.</returns>
        public static int Main(string[] args)
        {
            IConfiguration configuration = BootstrapConfiguration.ReadAppSettings();
            NihdiConfiguration = configuration.GetNihdiConfiguration();

            ILoggerFactory loggerFactory = BootstrapLoggerFactory.Create(NihdiConfiguration);
            ILogger<Program> logger = loggerFactory.CreateLogger<Program>();

            try
            {
                // ------ Configure builder
                WebApplicationBuilder builder = WebApplication.CreateBuilder(args);

                logger.LogStartApplication(NihdiConfiguration.Application.WorkloadName, NihdiConfiguration.Application.Environment);

                if (NihdiConfiguration.Application.EnvironmentIsDevTest())
                {
                    logger.LogDebug("NihdiConfiguration is '{0}'", JsonSerializer.Serialize(NihdiConfiguration));
                }

                // Add Blazor Server with Nihdi extensions.
                builder.AddBlazorServerForNihdi(NihdiConfiguration, logger);

                builder.AddOpenIdConnectForNihdi(NihdiConfiguration, logger);
                // Configure the antiforgery service as needed by our WAF
                builder.Services.AddAntiforgery(options =>
                {
                    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest; // needed to support http caused by WAF! :-(
                });

                // Configure Presentation Services
                builder.Services.AddMudServices();
                // builder.Services.ConfigureFindMyDoctorPresentationServices(NihdiConfiguration);

                builder.Services.AddHealthChecks();

                // Use Autofac
                new PresentationModule().RegisterDependencies(builder.Services);

                // ------ Configure WebApplication
                WebApplication app = builder.Build();

                // Use localization
                app.UseNihdiWebMiddleware(NihdiConfiguration, logger);

                app.UseBlazorInteractiveServerModeForNihdi<Presentation.Core.App>(logger);

                if (!NihdiConfiguration.Application.EnvironmentIsLocal())
                {
                    string basepath = $"/{NihdiConfiguration.Application.BusinessSystemName + NihdiConfiguration.Application.SubSystemName}";
                    logger.LogInformation("Use PathBase '{0}'", basepath);
                    app.UsePathBase(basepath);
                }

                logger.LogInformation("Host started successfully.");

                app.Run();

                return 0;
            }
            catch (Exception ex)
            {
                logger.LogHostTerminated(ex);
                return 1;
            }
            finally
            {
                // Delay so all logging is flushed. Log.CloseAndFlush will not work because we do not use the static logger.
                logger.LogInformation("Host has exited.");
                Task.Delay(1000).Wait();
            }
        }
    }
}