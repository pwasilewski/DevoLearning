﻿namespace Nihdi.DevoLearning.Host.Bff
{
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Diagnostics.HealthChecks;

    public class CustomHealthCheck : IHealthCheck
    {
        public Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default(CancellationToken))
        {
            // your logic here.
            bool checkOK = true;

            var result = new HealthCheckResult(
            status: checkOK ? HealthStatus.Healthy : HealthStatus.Unhealthy,
            description: $"Custom healthcheck",
            data: new Dictionary<string, object>()
                {
                    // severity if this check fails
                    { "Severity", "Critical" }
                });

            return Task.FromResult(result);
        }
    }
}
