﻿namespace Nihdi.DevoLearning.Host.Bff
{
    using Nihdi.Core.Configuration.Settings;
    using Nihdi.Core.Configuration.WebApi.WebApi;

    // Extension methods to organize configuration logic
    public static class WebApplicationBuilderExtensions
    {
        public static WebApplicationBuilder ConfigureWebApplicationBuilder(this WebApplicationBuilder builder, NihdiConfiguration nihdiConfiguration, ILoggerFactory loggerFactory)
        {
            // Configure the web application with Nihdi and logger settings
            builder.AddNihdiWebApi(nihdiConfiguration, loggerFactory.CreateLogger<Program>());
            return builder;
        }

        public static WebApplicationBuilder RegisterServices(this WebApplicationBuilder builder)
        {
            // Registers application-specific services and dependencies
            new BffModule().RegisterDependencies(builder.Services);
            return builder;
        }
    }
}
