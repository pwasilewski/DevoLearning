﻿// <copyright file="BffModule.cs" company="Riziv-Inami">
// Copyright (c) Riziv-Inami. All rights reserved.
// </copyright>

namespace Nihdi.DevoLearning.Host.Bff
{
    using Nihdi.DevoLearning.Core.Application;
    using Nihdi.DevoLearning.Core.Infrastructure;
    using Nihdi.DevoLearning.Core.Persistence;

    public class BffModule
    {
        public void RegisterDependencies(IServiceCollection services)
        {
            new PersistenceModule().RegisterDependencies(services);
            new ApplicationModule().RegisterDependencies(services);
            new InfrastructureModule().RegisterDependencies(services);
        }
    }
}