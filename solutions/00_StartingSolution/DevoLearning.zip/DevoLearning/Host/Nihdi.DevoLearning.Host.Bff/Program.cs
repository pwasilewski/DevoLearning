﻿namespace Nihdi.DevoLearning.Host.Bff
{
    using System.Diagnostics.Tracing;
    using Azure.Core.Diagnostics;
    using Microsoft.Extensions.Diagnostics.HealthChecks;
    using Nihdi.Core.Configuration;
    using Nihdi.Core.Configuration.Common.Logging;
    using Nihdi.Core.Configuration.Settings;
    using Nihdi.Core.Configuration.WebApi.WebApi;
    using Nihdi.Core.Health;
    using Nihdi.DevoLearning.Core.Persistence;
    using Serilog;

    public class Program
    {
        // Protected constructor to prevent instantiation of static class
        protected Program()
        {
        }

        /// <summary>
        /// The main entry point for the application. This method orchestrates the startup of two separate hosts: one for the Web API and another for NServiceBus.
        /// Separating the hosts allows for a clear division between the application's HTTP request handling and its background processing tasks.
        /// The Web API host handles incoming HTTP requests, serving as the interface for user interactions and external systems.
        /// Concurrently, the NServiceBus host processes messages and commands in the background, dealing with tasks such as data processing,
        /// integration events, and long-running operations without blocking the IIS threads. This architecture enhances scalability, maintainability,
        /// and allows for more resilient system design by isolating critical components of the application.
        /// </summary>
        /// <param name="args">Command-line arguments.</param>
        /// <returns>Returns an integer indicating success or failure, where 0 represents success and 1 represents failure.</returns>
        public static async Task<int> Main(string[] args)
        {
            // Initialize configuration and logging
            IConfiguration configuration = BootstrapConfiguration.ReadAppSettings();
            NihdiConfiguration nihdiConfiguration = configuration.GetNihdiConfiguration();
            ILoggerFactory loggerFactory = BootstrapLoggerFactory.Create(nihdiConfiguration);
            ILogger<Program> logger = loggerFactory.CreateLogger<Program>();

            try
            {
                // Create the web application
                WebApplication apiApp = CreateWebApplication(args, configuration, nihdiConfiguration, loggerFactory);

                // Starting the web application
                logger.LogInformation("Host started successfully.");
                await apiApp.RunAsync();

                return 0;
            }
            catch (Exception ex)
            {
                // Log any unhandled exceptions and return an error code
                logger.LogError(ex, "Host terminated unexpectedly.");
                return 1;
            }
            finally
            {
                // Ensures all logs are flushed before application exit
                logger.LogInformation("Host has exited.");
                await Log.CloseAndFlushAsync();
                await Task.Delay(1000);
            }
        }

        private static WebApplication CreateWebApplication(string[] args, IConfiguration configuration, NihdiConfiguration nihdiConfiguration, ILoggerFactory loggerFactory)
        {
            // Add logging for Azure Services
            ILogger<Program> logger = loggerFactory.CreateLogger<Program>();
            var listener = new AzureEventSourceListener(
                (eventData, text) =>
                    logger.Log(
                        eventData.Level.ToLogLevel(),
                        "[{1}] {0}: {2}",
                        eventData.Level.ToLogLevel(),
                        eventData.EventSource.Name,
                        text),
                EventLevel.Warning);

            // Initial configuration of the web application builder
            WebApplicationBuilder builder = WebApplication.CreateBuilder(args)
                .ConfigureWebApplicationBuilder(nihdiConfiguration, loggerFactory)
                .RegisterServices();

            builder.Services.AddHealthChecks()
                .AddDbContextCheck<DevoLearningDbContext>(failureStatus: HealthStatus.Unhealthy, tags: [HealthCheckTags.SeverityCritical])
                .AddCheck<CustomHealthCheck>("Custom HealthCheck");

            // Build the web application
            WebApplication app = builder.Build();

            // Setup middleware and other configurations
            app.UseNihdiWebApiMiddleware(nihdiConfiguration, loggerFactory.CreateLogger<Program>());

            return app;
        }
    }

    public static class EventLevelExtensions
    {
        public static LogLevel ToLogLevel(this EventLevel eventLevel)
        {
            switch (eventLevel)
            {
                case EventLevel.LogAlways:
                    return LogLevel.Trace;
                case EventLevel.Critical:
                    return LogLevel.Critical;
                case EventLevel.Error:
                    return LogLevel.Error;
                case EventLevel.Warning:
                    return LogLevel.Warning;
                case EventLevel.Informational:
                    return LogLevel.Information;
                case EventLevel.Verbose:
                    return LogLevel.Debug;
                default:
                    throw new ArgumentOutOfRangeException(nameof(eventLevel), eventLevel, null);
            }
        }
    }
}