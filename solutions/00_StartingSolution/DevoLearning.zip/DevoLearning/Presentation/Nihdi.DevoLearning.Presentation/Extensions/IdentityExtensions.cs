﻿namespace Nihdi.DevoLearning.Presentation.Shared
{
    using System.Security.Claims;
    using System.Security.Principal;

    public static class IdentityExtensions
    {
        public static string GetUserName(this IIdentity identity)
        {
            return identity.GetClaimValue(IdentityTokenClaimsNames.UserName);
        }

        public static string GetFirstName(this IIdentity identity)
        {
            return identity.GetClaimValue(IdentityTokenClaimsNames.FirstName);
        }

        public static string GetLastName(this IIdentity identity)
        {
            return identity.GetClaimValue(IdentityTokenClaimsNames.LastName);
        }

        public static string GetNationalNumber(this IIdentity identity)
        {
            return identity.GetClaimValue(IdentityTokenClaimsNames.NationalRegisterNumber);
        }

        public static string GetFullName(this IIdentity identity)
        {
            var lastName = identity.GetLastName();
            var firstName = identity.GetFirstName();

            return $"{firstName} {lastName}".Trim();
        }

        private static string GetClaimValue(this IIdentity identity, string claimType)
        {
            return (identity as ClaimsIdentity)?.Claims.SingleOrDefault(p => p.Type == claimType)?.Value ?? string.Empty;
        }
    }
}
