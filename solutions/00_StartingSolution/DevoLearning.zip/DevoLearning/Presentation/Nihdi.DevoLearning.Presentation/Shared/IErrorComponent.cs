﻿// <copyright file="IErrorComponent.cs" company="Riziv-Inami">
// Copyright (c) Riziv-Inami. All rights reserved.
// </copyright>

namespace Nihdi.DevoLearning.Presentation.Shared
{
    using Microsoft.AspNetCore.Components;

    public interface IErrorComponent
    {
        RenderFragment ChildContent
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the error message.
        /// </summary>
        /// <value>
        /// The error message.
        /// </value>
        string ErrorMessage
        {
            get; set;
        }

        /// <summary>
        /// Processes the error.
        /// </summary>
        /// <param name="ex">The ex.</param>
        void ProcessError(Exception ex);
    }
}