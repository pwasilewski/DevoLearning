﻿namespace Nihdi.DevoLearning.Presentation.Shared
{
    using System.Globalization;

    public static class CultureInfoOptions
    {
        public static CultureInfo FrenchCultureInfo { get; } = new CultureInfo("fr-BE");

        public static CultureInfo DutchCultureInfo { get; } = new CultureInfo("nl-BE");

        public static string GenerateSetLanguagePath(string originalUri, CultureInfo cultureInfo)
        {
            var uri = new Uri(originalUri).GetComponents(UriComponents.PathAndQuery, UriFormat.Unescaped);
            var cultureEscaped = Uri.EscapeDataString(cultureInfo.Name);
            var uriEscaped = Uri.EscapeDataString(uri);

            return $"Localization/SetLanguage?culture={cultureEscaped}&returnUrl={uriEscaped}";
        }
    }
}
