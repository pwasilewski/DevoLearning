﻿namespace Nihdi.DevoLearning.Presentation.Shared
{
    public static class IdentityTokenClaimsNames
    {
        public const string UserName = "name";
        public const string LastName = "last_name";
        public const string FirstName = "first_name";
        public const string NationalRegisterNumber = "national_register_number";
    }
}
