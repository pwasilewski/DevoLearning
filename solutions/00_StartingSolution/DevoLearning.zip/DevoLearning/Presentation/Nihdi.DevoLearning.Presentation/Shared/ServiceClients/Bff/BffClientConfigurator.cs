﻿namespace Nihdi.DevoLearning.Presentation.Shared.ServiceClients.Bff
{
    using Nihdi.Core.Configuration.Settings;
    using Nihdi.Core.Configuration.Settings.HttpClient;

    public static class BffClientConfigurator
    {
        public static IServiceCollection ConfigureBffServiceClient(this IServiceCollection services, NihdiConfiguration nidhiConfiguration)
        {
            HttpClientServiceConfiguration httpServiceConfiguration = nidhiConfiguration.HttpClientServiceRegistry[HttpClientServicesNames.Bff];
            /*
            services.AddNihdiHttpServiceClient<ILoadTestClient, LoadTestClient>(
                httpServiceConfiguration,
                httpClient =>
                {
                    httpClient.DefaultRequestHeaders.Add("NihDi-header", "My-Nihdi-custom-config");
                });
            */
            return services;
        }
    }
}
