﻿namespace Nihdi.DevoLearning.Presentation.Shared.Navigation
{
    using Microsoft.AspNetCore.Components;

    public class NavigationService(NavigationManager navigationManager) : INavigationService
    {
        public void NavigateTo(string uri) => navigationManager.NavigateTo(uri);
    }
}
