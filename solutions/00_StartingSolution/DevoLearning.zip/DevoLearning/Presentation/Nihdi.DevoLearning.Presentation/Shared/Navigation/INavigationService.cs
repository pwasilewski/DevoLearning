﻿namespace Nihdi.DevoLearning.Presentation.Shared.Navigation
{
    public interface INavigationService
    {
        void NavigateTo(string uri);
    }
}
