﻿// <copyright file="HttpClientServicesNames.cs" company="Riziv-Inami">
// Copyright (c) Riziv-Inami. All rights reserved.
// </copyright>

namespace Nihdi.DevoLearning.Presentation.Shared
{
    public static class HttpClientServicesNames
    {
        public const string Bff = "devoteam-learning-bff";
    }
}