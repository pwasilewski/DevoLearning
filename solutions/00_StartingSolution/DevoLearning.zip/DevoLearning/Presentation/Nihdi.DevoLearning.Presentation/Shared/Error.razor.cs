﻿// <copyright file="Error.razor.cs" company="Riziv-Inami">
// Copyright (c) Riziv-Inami. All rights reserved.
// </copyright>

namespace Nihdi.DevoLearning.Presentation.Shared
{
    using System;
    using Microsoft.AspNetCore.Components;
    using Microsoft.Extensions.Logging;
    using MudBlazor;

    /// <summary>
    /// The error.
    /// </summary>
    public partial class Error : IErrorComponent
    {
        public Error()
        {
        }

        /// <summary>
        /// Gets or sets the child content.
        /// </summary>
        [Parameter]
        public RenderFragment ChildContent
        {
            get; set;
        }

        /// <summary>
        /// Gets or sets the error message.
        /// </summary>
        public string ErrorMessage { get; set; } = string.Empty;

        /// <summary>
        /// Processes the error.
        /// </summary>
        /// <param name="ex">The ex.</param>
        public void ProcessError(Exception ex)
        {
            this.Snackbar.Configuration.PositionClass = Defaults.Classes.Position.BottomLeft;
            this.Logger.LogError(
                "Error:ProcessError - Type: {Type} Exception: '{Exception}'",
                ex.GetType(),
                ex.ToString());
            this.Snackbar.Add($"An exception occurred:  - Type: {ex.GetType()} Message: {ex.Message}", Severity.Error);
            StateHasChanged();
        }
    }
}