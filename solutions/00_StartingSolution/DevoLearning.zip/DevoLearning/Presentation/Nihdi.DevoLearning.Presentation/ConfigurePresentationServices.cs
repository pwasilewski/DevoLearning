﻿// <copyright file="ConfigurePresentationServices.cs" company="Riziv-Inami">
// Copyright (c) Riziv-Inami. All rights reserved.
// </copyright>

namespace Nihdi.DevoLearning.Presentation
{
    using Microsoft.Extensions.DependencyInjection;
    using Nihdi.Core.Configuration.Settings;
    using Nihdi.DevoLearning.Presentation.Shared.ServiceClients.Bff;

    public static class ConfigurePresentationServices
    {
        public static void ConfigureFindMyDoctorPresentationServices(this IServiceCollection services, NihdiConfiguration nidhiConfiguration)
        {
            services.ConfigureBffServiceClient(nidhiConfiguration);
        }
    }
}