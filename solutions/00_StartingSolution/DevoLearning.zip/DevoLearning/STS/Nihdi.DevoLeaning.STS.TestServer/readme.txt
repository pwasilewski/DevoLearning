﻿Launching up a console using the Nihdi.IdentityModel.OpenIdConnect.DevTokenServer starts a local OIDC compliant server that provides limited OpenIdConnect functionality. The configuration is performed statically by means of an appsettings.json file.

Following flows are supported:

 - Implicit flow
 - Authorization code grant flow with PKCE support
 - Refresh token flow
 - Client credentials flow 
 - Hybrid flow 
 
 The appsettings.json configuration is fairly straightforward, it consists of three functional blocks:
 
 - Configuration of the OIDC clients
 - Configuration of the id and access token
 - Configuration of the client credentials token
 - Configuration of the userinfo token
 
 Except for the scopes parameter, multivalue parameters are passed as a string where the values are separated by a | character.

 Make sure the 'Copy to Output Directory' property for the file appsettings.json is set to make the configuration 
 settings available to the authorization server.
 
 Configuration of the OIDC client
 ================================
 Here you will need to configure the following parameters:
 
 - BaseUrl: The base URL of the authorization server that hosts the auth and token endpoints. Scheme need to be https.
 - LogParameters: When set to true, the client configuration will be shown in the console at startup.
 - UsePKCE: This flag sets whether you want to have PKCE support for your authorization code grant flow.
 - AccessTokenLifetime: the lifetime in minutes of the access tokens issued by the dev token server.
 - RefreshTokenLifetime: the lifetime in minutes of the refresh tokens issued by the dev token server.    
 - ClientId: The identifier of the client.
 - ClientSecret: The local dev token server considers the client to be a confidential client, therefore you need to set a value for the secret. 
 - Scopes: A list of supported scopes. The dev token server will only verify the validity of the scopes in the OIDC request, it does not however use the requested scopes to determine what claims the returned tokens should contain.
 - RedirectUri: A required parameter, is the return address where the requested tokens need to be sent to. The local dev token server does not actively use the parameter, it is only there because the OIDC protocol demands it.
 
 Configuration of the id and access token
 ========================================
 This section is used to determine the contents of the id and access token returned by the local dev token server.
 There are three parts:
 
	- Common: To avoid having to repeat the claims that need to go in both tokens you can put here the list of claims for both tokens.				
		
	- IdToken: Here you put the claims that only need to be included in the id token.
	
	- AccessToken: Here you put the claims that only need to be included in the access token.

	- ClientCredentialsToken: Here you put the claims that only need to be included in the client credentials token.

	Remarks: 
	
	- Due to a limitation of the OIDC middleware I have used for the local dev token server, you cannot add the same claim with different values to the id and access token. As a consequence, you cannot have a different role set in the id and access token.
	- The .NET configuration based on JSON files does not support using a colon in the key (as the colon is used to determine hierarchy). Since legacy SOAP claim types, e.g. http://schemas.microsoft.com/ws/2008/06/identity/claims/role, use a colon we can not use the SOAP claim type as key. 
	  A simple solution is to omit the scheme from the SOAP claim type in the configuration, the local dev token server adds the prefix http:// when it sees a claim type that starts with 'schemas.'.

	  So to configure as set of roles using SOAP claimtypes in the appsettings.json file you would use:

	  "schemas.microsoft.com/ws/2008/06/identity/claims/role": "role1|role2|role3..."

	  The local dev server will return:

	   "http://schemas.microsoft.com/ws/2008/06/identity/claims/role": [
			"Role1",
			"Role2",
			"Role3",
			...]
	
	Configuration of the userinfo token
	===================================
	This section is used to determine the claim contents of userinfo token.