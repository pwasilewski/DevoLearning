﻿namespace Nihdi.DevoLearning.Core.Persistence
{
    using Microsoft.EntityFrameworkCore;

    /// <summary>
    /// The database service configure the entity mappings and exposes the entities.
    /// </summary>
    public class DevoLearningDbContext : DbContext, IDevoLearningDbContext
    {
        public DevoLearningDbContext(DbContextOptions options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.ApplyConfigurationsFromAssembly(GetType().Assembly);
        }
    }
}
