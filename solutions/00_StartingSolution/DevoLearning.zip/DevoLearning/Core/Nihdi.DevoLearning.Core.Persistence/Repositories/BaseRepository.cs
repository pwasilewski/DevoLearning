﻿// <copyright file="BaseRepository.cs" company="Riziv-Inami">
// Copyright (c) Riziv-Inami. All rights reserved.
// </copyright>

namespace Nihdi.DevoLearning.Core.Persistence
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.EntityFrameworkCore;
    using Nihdi.Core.Functional;
    using Nihdi.DevoLearning.Core.Application.Shared.Interfaces.Persistence;

    public class BaseRepository<T> : IRepository<T>
        where T : class
    {
        public BaseRepository(DevoLearningDbContext dbContext)
        {
            Preconditions.NotNull(dbContext, nameof(dbContext));
            DbContext = dbContext;
        }

        protected DevoLearningDbContext DbContext
        {
            get; private set;
        }

        public virtual async Task<T> GetByIdAsync(int id)
        {
            T t = await DbContext.Set<T>().FindAsync(id);
            return t;
        }

        public async Task<IReadOnlyList<T>> ListAllAsync()
        {
            return await DbContext.Set<T>().ToListAsync();
        }

        public async virtual Task<IReadOnlyList<T>> GetPagedReponseAsync(int page, int size)
        {
            return await DbContext.Set<T>().Skip((page - 1) * size).Take(size).AsNoTracking().ToListAsync();
        }

        public async Task<T> AddAsync(T entity)
        {
            await DbContext.Set<T>().AddAsync(entity);
            return entity;
        }

        public void Update(T entity)
        {
            DbContext.Entry(entity).State = EntityState.Modified;
        }

        public void Delete(T entity)
        {
            DbContext.Set<T>().Remove(entity);
        }

        public async Task SaveChangesAsync()
        {
            await DbContext.SaveChangesAsync();
        }
    }
}