﻿// <copyright file="PersistenceModule.cs" company="Riziv-Inami">
// Copyright (c) Riziv-Inami. All rights reserved.
// </copyright>

namespace Nihdi.DevoLearning.Core.Persistence
{
    using Microsoft.Extensions.DependencyInjection;

    public class PersistenceModule
    {
        public void RegisterDependencies(IServiceCollection services)
        {
            // Repository convention
            services.Scan(scan => scan.FromAssemblyOf<PersistenceModule>()
            .AddClasses(classes => classes.Where(t => t.Name.EndsWith("Repository")))
                .AsImplementedInterfaces()
                .WithScopedLifetime());
        }
    }
}