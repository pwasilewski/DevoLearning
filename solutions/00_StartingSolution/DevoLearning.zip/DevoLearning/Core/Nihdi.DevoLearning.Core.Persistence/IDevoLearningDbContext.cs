﻿namespace Nihdi.DevoLearning.Core.Persistence
{
    /// <summary>
    /// The database service configure the entity mappings and exposes the entities.
    /// </summary>
    public interface IDevoLearningDbContext
    {
    }
}
