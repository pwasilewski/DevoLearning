﻿namespace Nihdi.DevoLearning.Core.Domain.Shared
{
    public interface IEntity
    {
        int Id
        {
            get; set;
        }
    }
}
