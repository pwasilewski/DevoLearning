﻿namespace Nihdi.DevoLearning.Core.Application.Shared.Interfaces.Persistence
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    public interface IRepository<T>
        where T : class
    {
        Task<T> GetByIdAsync(int id);

        Task<IReadOnlyList<T>> ListAllAsync();

        Task<T> AddAsync(T entity);

        void Update(T entity);

        void Delete(T entity);

        Task<IReadOnlyList<T>> GetPagedReponseAsync(int page, int size);

        Task SaveChangesAsync();
    }
}
