﻿namespace Nihdi.DevoLearning.Core.Application
{
    using Microsoft.Extensions.DependencyInjection;
    using Nihdi.Core.Functional;

    public class ApplicationModule
    {
        public void RegisterDependencies(IServiceCollection services)
        {
            services.Scan(scan => scan.FromAssemblyOf<ApplicationModule>()
                .AddClasses(classes => classes.Where(t => t.Name.EndsWith("Query")))
                    .AsImplementedInterfaces()
                    .WithScopedLifetime()
                .AddClasses(classes => classes.Where(t => t.Name.EndsWith("Handler")))
                    .AsImplementedInterfaces()
                    .WithScopedLifetime()
                .AddClasses(classes => classes.AssignableTo(typeof(ICommandHandler<,>)))
                    .AsImplementedInterfaces()
                    .WithScopedLifetime());
        }
    }
}
