﻿using Microsoft.Extensions.DependencyInjection;

namespace Nihdi.DevoLearning.Core.Infrastructure
{
    public class InfrastructureModule
    {
        public void RegisterDependencies(IServiceCollection services)
        {
            // Service convention
            services.Scan(scan => scan.FromAssemblyOf<InfrastructureModule>()
            .AddClasses(classes => classes.Where(t => t.Name.EndsWith("Service")))
                .AsImplementedInterfaces()
                .WithScopedLifetime());
        }
    }
}
