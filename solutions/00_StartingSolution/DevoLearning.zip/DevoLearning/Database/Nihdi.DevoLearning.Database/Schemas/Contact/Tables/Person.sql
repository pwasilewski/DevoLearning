﻿CREATE TABLE [contact].[Person]
(
    [Id] INT IDENTITY(1,1) NOT NULL,
    [FirstName] NVARCHAR(100) NOT NULL,
    [LastName] NVARCHAR(100) NOT NULL,
    [Gender] TINYINT NOT NULL,
    [CivilState] TINYINT NOT NULL,
    [BirthDate] DATETIME2(3) NULL,
    [DeceasedDate] DATETIME2(3) NULL,
    [Email] NVARCHAR(200) NULL,
    [PhoneNumber] NVARCHAR(50) NULL,
    [CreatedOn] DATETIME2(3) NOT NULL DEFAULT (GETDATE()),
    [CreatedBy] NVARCHAR(50) NOT NULL,
    [ModifiedOn] DATETIME2(3) NULL,
    [ModifiedBy] NVARCHAR(50) NULL,

    CONSTRAINT [PK_Person] PRIMARY KEY CLUSTERED ([Id] ASC),
);